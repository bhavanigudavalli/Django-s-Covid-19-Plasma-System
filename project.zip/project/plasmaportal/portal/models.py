import csv
from django.http import HttpResponse
from django.db import models
from django.contrib import admin
from datetime import date
from datetime import timedelta
from django.core.exceptions import ValidationError
from django.contrib import messages
from django.db.models import Avg, Max, Min, Sum


# Create your models here.


def limit_donors_30days():
    days30 = date.today() + timedelta(days=-30)
    return {'CovidNegativeDate__lte': days30}

State_CHOICES = [
    ('AP', 'Andhra Pradesh'),
    ('AR', 'Arunchal Pradesh'),
    ('AS', 'Assam'),
    ('BR', 'Bihar'),
    ('CG', 'Chhattisgarh'),
    ('CH', 'Chandigarh'),
    ('DL', 'Delhi'),
    ('GA', 'Goa'),
    ('GJ', 'Gujarat'),
    ('HR', 'Haryana'),
    ('HP', 'Himachal Pradesh'),
    ('JK', 'Jammu And Kashmir'),
    ('JH', 'Jharkhand'),
    ('KA', 'Karnataka'),
    ('KL', 'Kerala'),
    ('MP', 'Madhya Pradesh'),
    ('MH', 'Maharashtra'),
    ('MN', 'Manipur'),
    ('ML', 'Meghalaya'),
    ('MZ', 'Mizoram'),
    ('NL', 'Nagaland'),
    ('OR', 'Orissa'),
    ('PB', 'Punjab'),
    ('RJ', 'Rajasthan'),
    ('SK', 'Sikkim'),
    ('TN', 'Tamil Nadu'),
    ('TR', 'Tripura'),
    ('UK', 'Uttarakhand'),
    ('UP', 'Uttar Pradesh'),
    ('WB', 'West Bengal')
]
class Hospital(models.Model):
    HospitalID = models.IntegerField
    Name = models.CharField(max_length=100, blank=False)
    City = models.CharField(max_length=100)
    District = models.CharField(max_length=100)
    State = models.CharField(max_length=100,choices=State_CHOICES)
    Pincode = models.CharField(max_length=6)
    Phone = models.CharField(max_length=20)
    Contact = models.CharField(max_length=100)
    ACtive = models.BooleanField

    def __str__(self):
        return f"{self.Name}, {self.City}"

    def clean(self):
        if (len(self.Phone) < 10 or len(self.Phone)>10):
            raise ValidationError("Please enter valid Phone Number it must contain 10 digits")

    class Meta:
        ordering = ("City", "Name")


class Bloodbank(models.Model):
    BloodbankID = models.IntegerField
    Name = models.CharField(max_length=100)
    City = models.CharField(max_length=100)
    District = models.CharField(max_length=100)
    State = models.CharField(max_length=100,choices=State_CHOICES)
    Pincode = models.CharField(max_length=6)
    Phone = models.CharField(max_length=20)
    Contact = models.CharField(max_length=100)
    ACtive = models.BooleanField

    def __str__(self):
        return f"{self.Name}, {self.City}"
    def clean(self):
        if (len(self.Phone) < 10 or len(self.Phone)>10):
            raise ValidationError("Please enter valid Phone Number it must contain 10 digits")



BLOODGROUP_CHOICES = [
    ('A RhD positive', 'A+'),
    ('A RhD negative', 'A-'),
    ('B RhD positive', 'B+'),
    ('B RhD negative', 'B-'),
    ('O RhD positive', 'O+'),
    ('O RhD negative', 'O-'),
    ('AB RhD positive', 'AB+'),
    ('AB RhD negative', 'AB-'),
]

GENDER_CHOICES = [
    ('Male', 'M'),
    ('Female', 'F'),
]


medical_CHOICES = [('Y', 'YES'),
                   ('N', 'NO')]



class Donor(models.Model):
    DonorID = models.IntegerField
    Name = models.CharField(max_length=100)
    Age = models.IntegerField
    Gender = models.CharField(max_length=10,
                              choices=GENDER_CHOICES)
    City = models.CharField(max_length=100)
    District = models.CharField(max_length=100)
    State = models.CharField(max_length=100, choices=State_CHOICES)
    Pincode = models.CharField(max_length=6)
    Phone = models.CharField(max_length=10)
    Contact = models.CharField(max_length=100)
    Active = models.BooleanField
    BloodGroup = models.CharField(max_length=30,
                                  choices=BLOODGROUP_CHOICES)
    CancerPatient = models.CharField(max_length=3, default='NO',choices=medical_CHOICES)
    HeartDisease = models.CharField(max_length=3,default='NO', choices=medical_CHOICES)
    DiabetesPatient = models.CharField(max_length=30,default='NO',
                                       choices=medical_CHOICES)
    Obesity = models.CharField(max_length=30, default='NO',
                               choices=medical_CHOICES)
    CovidPositiveDate = models.DateField(default=date.today())
    CovidNegativeDate = models.DateField(default=date.today())

    def __str__(self):
        return f"{self.Name}, {self.City}"

    def clean(self):
        if self.Obesity == 'Y' or self.CancerPatient == 'Y' or self.DiabetesPatient == 'Y' or self.HeartDisease == 'Y':
            raise ValidationError(
                "Please make ensure that the donor must be free of chronic diseases to be eligible for donation")
        if (len(self.Phone) < 10 or len(self.Phone)>10):
            raise ValidationError("Please enter valid Phone Number it must contain 10 digits")


class Recipient(models.Model):
    RecipientID = models.IntegerField
    Name = models.CharField(max_length=100)
    Age = models.IntegerField
    Aadhar = models.CharField(max_length=12,default=0)
    Gender = models.CharField(max_length=10,
                              choices=GENDER_CHOICES)
    City = models.CharField(max_length=100)
    District = models.CharField(max_length=100)
    State = models.CharField(max_length=100,choices=State_CHOICES)
    Pincode = models.CharField(max_length=6)
    Phone = models.CharField(max_length=20)
    Contact = models.CharField(max_length=100)
    ACtive = models.BooleanField
    BloodGroup = models.CharField(max_length=30,
                                  choices=BLOODGROUP_CHOICES)
    PlasmaDelivered = models.BooleanField(null=True)
    PlasmaQuantity = models.PositiveIntegerField(null=True)
    PlasmaDeliveryDate = models.DateField(null=True)

    def __str__(self):
        return f"{self.Name},{self.City}"

    def clean(self):
        availableqty = int(
            Plasma.objects.filter(Bloodgroup=self.BloodGroup).aggregate(Sum('AvailableQty')).get('AvailableQty__sum',
                                                                                                 0.0) or 0)
        if self.PlasmaQuantity > availableqty:
            raise ValidationError("Requested Quantity is not available....(Available Qty:" + str(availableqty) + ")")
        if (len(self.Aadhar) < 12):
            raise ValidationError("Please enter valid AAdhar Number it must contain 12 digits")
        if (len(self.Phone) < 10  or len(self.Phone)>10):
            raise ValidationError("Please enter valid Phone Number it must contain 10 digits")


class Patient(models.Model):
    PatientID = models.IntegerField
    Name = models.CharField(max_length=100)
    Age = models.IntegerField
    Gender = models.CharField(max_length=10,
                              choices=GENDER_CHOICES)
    City = models.CharField(max_length=100)
    District = models.CharField(max_length=100)
    State = models.CharField(max_length=100,choices=State_CHOICES)
    Pincode = models.CharField(max_length=6)
    Phone = models.CharField(max_length=20)
    Contact = models.CharField(max_length=100)
    ACtive = models.BooleanField
    BloodGroup = models.CharField(max_length=30,
                                  choices=BLOODGROUP_CHOICES)

    def __str__(self):
        return f"{self.Name}, {self.City}"


RATING_CHOICES = [
    ('1 Star', '1'),
    ('2 Star', '2'),
    ('3 Star', '3'),
    ('4 Star', '4'),
    ('5 Star', '5'),
]

QUALITY_CHOICES = [
    ('Good', 'G'),
    ('Average', 'A'),
    ('Poor', 'P'),
]

STATUS_CHOICES = [
    ('Available', 'A'),
    ('Not Available', 'N'),
]


class Plasma(models.Model):
    PlasmaID = models.IntegerField
    Bloodbank = models.ForeignKey(Bloodbank, default=1, verbose_name="Bloodbank", on_delete=models.SET_DEFAULT)
    Bloodgroup = models.CharField(max_length=30,
                                  choices=BLOODGROUP_CHOICES)
    Donor = models.ForeignKey(Donor, default=1, verbose_name="Donor", on_delete=models.SET_DEFAULT,
                              limit_choices_to=limit_donors_30days)
    DonationDate = models.DateField
    """Status = models.CharField(max_length=20,default='A',
                              choices=STATUS_CHOICES)"""
    AvailableQty = models.PositiveIntegerField(default=0)

    class Meta:
        verbose_name_plural = "Plasma List"


class Feedback(models.Model):
    FeedbackID = models.IntegerField
    Name = models.CharField(max_length=100)
    FeedbackDate = models.DateField
    Comments = models.CharField(max_length=250)
    Rating = models.CharField(max_length=10, choices=RATING_CHOICES)

    def __str__(self):
        return f"{self.Rating}, {self.Name}"
