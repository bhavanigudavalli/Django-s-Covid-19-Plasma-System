from django import forms
from django.core.exceptions import ValidationError
GENDER_CHOICES =[
    ('Male', 'M'),
    ('Female', 'F'),
]

BLOODGROUP_CHOICES = [
    ('A RhD positive', 'A+'),
    ('A RhD negative', 'A-'),
    ('B RhD positive', 'B+'),
    ('B RhD negative', 'B-'),
    ('O RhD positive', 'O+'),
    ('O RhD negative', 'O-'),
    ('AB RhD positive', 'AB+'),
    ('AB RhD negative', 'AB-'),
]
State_CHOICES = [
    ('AP', 'Andhra Pradesh'),
    ('AR', 'Arunchal Pradesh'),
    ('AS', 'Assam'),
    ('BR', 'Bihar'),
    ('CG', 'Chhattisgarh'),
    ('CH', 'Chandigarh'),
    ('DL', 'Delhi'),
    ('GA', 'Goa'),
    ('GJ', 'Gujarat'),
    ('HR', 'Haryana'),
    ('HP', 'Himachal Pradesh'),
    ('JK', 'Jammu And Kashmir'),
    ('JH', 'Jharkhand'),
    ('KA', 'Karnataka'),
    ('KL', 'Kerala'),
    ('MP', 'Madhya Pradesh'),
    ('MH', 'Maharashtra'),
    ('MN', 'Manipur'),
    ('ML', 'Meghalaya'),
    ('MZ', 'Mizoram'),
    ('NL', 'Nagaland'),
    ('OR', 'Orissa'),
    ('PB', 'Punjab'),
    ('RJ', 'Rajasthan'),
    ('SK', 'Sikkim'),
    ('TN', 'Tamil Nadu'),
    ('TR', 'Tripura'),
    ('UK', 'Uttarakhand'),
    ('UP', 'Uttar Pradesh'),
    ('WB', 'West Bengal')
    ]
class RegisterForm(forms.Form):
    name = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    gender = forms.CharField(widget=forms.Select(choices=GENDER_CHOICES))
    aadhar = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    city = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    district = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    state = forms.CharField(widget=forms.Select(choices=State_CHOICES))
    pincode = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    phone = forms.CharField(widget=forms.NumberInput(attrs={'class':'form-control'}))
    contact = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    bloodgroup = forms.CharField(widget=forms.Select(choices=BLOODGROUP_CHOICES))
    password = forms.CharField(widget=forms.PasswordInput())

    #password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'input-text with-border'}))
    """def clean(self):
        cleaned_data=super().clean()
        val_aadhar=self.cleaned_data['aadhar']
        if(len(val_aadhar)<12):
            raise ValidationError("Please enter valid Aadhar Number it must be in 12 digits")
        val_phone = self.cleaned_data['phone']
        if (len(val_phone) < 10):
            raise ValidationError("Please enter valid Phone Number it must be in 10 digits")

    def clean_password(self):
        password = self.cleaned_data['password']
        if len(password) < 4:
            raise forms.ValidationError("password is too short")
        return password"""
