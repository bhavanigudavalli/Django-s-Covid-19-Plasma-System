from django.shortcuts import render
from django.db.models import Avg, Max, Min, Sum
# Create your views here.
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from .models import Bloodbank, Hospital, Patient, Donor, Recipient, Feedback, Plasma
from django.contrib.auth import get_user_model
from .forms import RegisterForm
from django.shortcuts import redirect
from django.contrib import messages


def user_register(request):
    # recipient registration form
    # if this is a POST request we need to process the form data
    template = 'registration/register.html'

    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = RegisterForm(request.POST)
        # check whether it's valid:
        #aadhar = request.POST.get('aadhar')
        if form.is_valid():
            if Recipient.objects.filter(Aadhar=form.cleaned_data['aadhar']).exists():
                return render(request, template, {
                    'form': form,
                    'error_message': 'Recipient aadhar already exists.'
                })
            else:
            # Create the recipient:
                recipient = Recipient.objects.create(Name=form.cleaned_data['name'],
                                                     Aadhar=form.cleaned_data['aadhar'],
                                                     Phone=form.cleaned_data['phone'],
                                                     Gender=form.cleaned_data['gender'], City=form.cleaned_data['city'],
                                                     District=form.cleaned_data['district'],
                                                     State=form.cleaned_data['state'],
                                                     Pincode=form.cleaned_data['pincode'],
                                                     Contact=form.cleaned_data['contact'],
                                                     BloodGroup=form.cleaned_data['bloodgroup'],
                                                     password=form.cleaned_data['password'])
                # recipient =Recipient.objects.create()

                recipient.Name = form.cleaned_data['name']
                recipient.Aadhar = form.cleaned_data['aadhar']
                recipient.Phone = form.cleaned_data['phone']
                recipient.Gender = form.cleaned_data['gender']
                recipient.City = form.cleaned_data['city']
                recipient.District = form.cleaned_data['district']
                recipient.State = form.cleaned_data['state']
                recipient.Pincode = form.cleaned_data['pincode']
                recipient.Contact = form.cleaned_data['contact']
                recipient.bloodgroup = form.cleaned_data['bloodgroup']
                recipient.password = form.cleaned_data['password']
                #recipient.confirmpassword = form.cleaned_data['confirmpassword']

                recipient.save()

                # Login the user
                # login(request, user)

                # redirect to accounts page:
                # return HttpResponseRedirect('/')

                messages.success(request, 'Recipient Data has been added...')
                # return redirect("/")



    # No post data availabe, let's just show the page.
    else:
        form = RegisterForm()

    return render(request, template, {'form': form})


@login_required
# def index(request):
#    return HttpResponse("Hello, world. You're at the plasma portal.")

def index(request):
    num_bloodbanks = Bloodbank.objects.all().count()
    num_hospitals = Hospital.objects.all().count()
    num_donors = Donor.objects.all().count()
    num_patients = Donor.objects.all().count()
    num_recipients = Recipient.objects.all().count()
    num_plasma = Plasma.objects.all().count()
    num_feedback = Feedback.objects.all().count()

    apositive_qty = int(
        Plasma.objects.filter(Bloodgroup='A RhD positive').aggregate(Sum('AvailableQty')).get('AvailableQty__sum',
                                                                                              0.0) or 0) - int(
        Recipient.objects.filter(BloodGroup='A RhD positive', PlasmaDelivered=True).aggregate(
            Sum('PlasmaQuantity')).get('PlasmaQuantity__sum', 0.0) or 0)
    anegative_qty = int(
        Plasma.objects.filter(Bloodgroup='A RhD negative').aggregate(Sum('AvailableQty')).get('AvailableQty__sum',
                                                                                              0.0) or 0) - int(
        Recipient.objects.filter(BloodGroup='A RhD negative', PlasmaDelivered=True).aggregate(
            Sum('PlasmaQuantity')).get('PlasmaQuantity__sum', 0.0) or 0)
    bpositive_qty = int(
        Plasma.objects.filter(Bloodgroup='B RhD positive').aggregate(Sum('AvailableQty')).get('AvailableQty__sum',
                                                                                              0.0) or 0) - int(
        Recipient.objects.filter(BloodGroup='B RhD positive', PlasmaDelivered=True).aggregate(
            Sum('PlasmaQuantity')).get('PlasmaQuantity__sum', 0.0) or 0)
    bnegative_qty = int(
        Plasma.objects.filter(Bloodgroup='B RhD negative').aggregate(Sum('AvailableQty')).get('AvailableQty__sum',
                                                                                              0.0) or 0) - int(
        Recipient.objects.filter(BloodGroup='B RhD negative', PlasmaDelivered=True).aggregate(
            Sum('PlasmaQuantity')).get('PlasmaQuantity__sum', 0.0) or 0)
    opositive_qty = int(
        Plasma.objects.filter(Bloodgroup='O RhD positive').aggregate(Sum('AvailableQty')).get('AvailableQty__sum',
                                                                                              0.0) or 0) - int(
        Recipient.objects.filter(BloodGroup='O RhD positive', PlasmaDelivered=True).aggregate(
            Sum('PlasmaQuantity')).get('PlasmaQuantity__sum', 0.0) or 0)
    onegative_qty = int(
        Plasma.objects.filter(Bloodgroup='O RhD negative').aggregate(Sum('AvailableQty')).get('AvailableQty__sum',
                                                                                              0.0) or 0) - int(
        Recipient.objects.filter(BloodGroup='O RhD negative', PlasmaDelivered=True).aggregate(
            Sum('PlasmaQuantity')).get('PlasmaQuantity__sum', 0.0) or 0)
    abpositive_qty = int(
        Plasma.objects.filter(Bloodgroup='AB RhD positive').aggregate(Sum('AvailableQty')).get('AvailableQty__sum',
                                                                                               0.0) or 0) - int(
        Recipient.objects.filter(BloodGroup='AB RhD positive', PlasmaDelivered=True).aggregate(
            Sum('PlasmaQuantity')).get('PlasmaQuantity__sum', 0.0) or 0)
    abnegative_qty = int(
        Plasma.objects.filter(Bloodgroup='AB RhD negative').aggregate(Sum('AvailableQty')).get('AvailableQty__sum',
                                                                                               0.0) or 0) - int(
        Recipient.objects.filter(BloodGroup='AB RhD negative', PlasmaDelivered=True).aggregate(
            Sum('PlasmaQuantity')).get('PlasmaQuantity__sum', 0.0) or 0)
    user = get_user_model()
    num_users = user.objects.all().count()
    hospital_perm = request.user.has_perm('portal.view_hosptial')
    donor_perm = request.user.has_perm('portal.view_donor')
    patient_perm = request.user.has_perm('portal.view_patient')
    feedback_perm = request.user.has_perm('portal.view_feedback')
    bloodbank_perm = request.user.has_perm('portal.view_bloodbank')
    plasma_perm = request.user.has_perm('portal.view_plasma')
    recipient_perm = request.user.has_perm('portal.view_recipient')
    group_perm = request.user.has_perm('auth.view_group')
    user_perm = request.user.has_perm('auth.view_user')
    context = {
        'apositive_qty': apositive_qty,
        'anegative_qty': anegative_qty,
        'bpositive_qty': bpositive_qty,
        'bnegative_qty': bnegative_qty,
        'opositive_qty': opositive_qty,
        'onegative_qty': onegative_qty,
        'abpositive_qty': abpositive_qty,
        'abnegative_qty': abnegative_qty,
        'num_bloodbanks': num_bloodbanks,
        'num_hospitals': num_hospitals,
        'num_donors': num_donors,
        'num_patients': num_patients,
        'num_recipients': num_recipients,
        'num_plasma': num_plasma,
        'num_feedback': num_feedback,
        'num_users': num_users,
        'hospital_perm': hospital_perm,
        'donor_perm': donor_perm,
        'patient_perm': patient_perm,
        'feedback_perm': feedback_perm,
        'bloodbank_perm': bloodbank_perm,
        'plasma_perm': plasma_perm,
        'recipient_perm': recipient_perm,
        'group_perm': group_perm,
        'user_perm': user_perm,
    }
    # Render the HTML template index.html with the data in the context variable
    return render(request, 'index.html', context=context)